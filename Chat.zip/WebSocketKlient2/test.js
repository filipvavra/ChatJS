const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

var jmeno = ""
var jmeno1 = ""

while (jmeno1 =! "odpojit"){
    rl.question('What is your name? ', (jmeno) => {
        console.log(`Hello ${jmeno}!`);
        jmeno1 = jmeno;
    });
    jmeno1 = jmeno;
}